package automationLogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.asserts.Assertion;
import org.testng.asserts.SoftAssert;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginTest1 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
WebDriverManager.chromedriver().setup();
WebDriver driver=new ChromeDriver();

driver.get("https://platformrc.wyscout.com/app/");
Thread.sleep(3000);
By username=By.id("login_username");
By password=By.id("login_password");
By signin=By.id("login_button");


driver.findElement(username).sendKeys("polkajal22@gmail.com");
driver.findElement(password).sendKeys("pw_IndiaTest!");
driver.findElement(signin).click();
String title=driver.getTitle();
System.out.println(title);
Assertion softAssert=new SoftAssert();
softAssert.assertEquals(title, "Wyscout Platform");
System.out.println("Login Successful");

	}

}
