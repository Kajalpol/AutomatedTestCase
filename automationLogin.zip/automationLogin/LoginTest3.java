package automationLogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.asserts.Assertion;
import org.testng.asserts.SoftAssert;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginTest3 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
WebDriverManager.chromedriver().setup();
WebDriver driver=new ChromeDriver();

driver.get("https://platformrc.wyscout.com/app/");
Thread.sleep(3000);
By username=By.id("login_username");
By password=By.id("login_password");
By signin=By.id("login_button");


driver.get("https://platformrc.wyscout.com/app/");
driver.findElement(username).sendKeys("kajalpol@gmail.com");
driver.findElement(password).sendKeys("Satara@123");
driver.findElement(signin).click();
String title2=driver.getTitle();
System.out.println(title2);
Assertion softAssert2=new SoftAssert();
softAssert2.assertEquals(title2, "Wyscout Platform");
System.out.println("Login Unsuccessful");

	}

}
